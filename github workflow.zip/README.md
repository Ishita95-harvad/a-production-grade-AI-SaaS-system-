# BookMyShow AI Clone

Full setup and deployment instructions.
