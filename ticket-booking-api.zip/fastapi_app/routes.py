from fastapi import APIRouter
from fastapi_app.booking import get_shows, book_ticket

router = APIRouter()

@router.get("/api/shows")
def shows():
    return get_shows()

@router.post("/api/booking")
def booking(data: dict):
    return book_ticket(data)
