# Ticket Booking API

A Flask-based ticket booking API with Docker and Kubernetes deployment files.

## Features
- List movie shows
- Book tickets via API
- Dockerized setup
- Kubernetes manifests for deployment
