from flask import Blueprint, request, jsonify
from app.booking import book_ticket, get_shows

api = Blueprint('api', __name__)

@api.route('/api/shows', methods=['GET'])
def list_shows():
    return jsonify(get_shows())

@api.route('/api/booking', methods=['POST'])
def create_booking():
    data = request.get_json()
    return jsonify(book_ticket(data))
