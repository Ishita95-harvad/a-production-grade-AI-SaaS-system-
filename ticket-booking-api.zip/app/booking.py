def get_shows():
    return [
        {"id": 1, "movie": "Inception", "time": "7 PM"},
        {"id": 2, "movie": "Interstellar", "time": "9 PM"}
    ]

def book_ticket(data):
    return {
        "status": "success",
        "message": f"Ticket booked for {data['movie']} at {data['time']}"
    }
